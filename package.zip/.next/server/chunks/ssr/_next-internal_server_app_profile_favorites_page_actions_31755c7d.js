module.exports=[83161,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_profile_favorites_page_actions_31755c7d.js.map