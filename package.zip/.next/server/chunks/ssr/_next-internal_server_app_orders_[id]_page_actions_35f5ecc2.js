module.exports=[94709,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_orders_%5Bid%5D_page_actions_35f5ecc2.js.map