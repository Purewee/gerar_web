module.exports=[6735,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_orders_create_page_actions_bd16fd6b.js.map