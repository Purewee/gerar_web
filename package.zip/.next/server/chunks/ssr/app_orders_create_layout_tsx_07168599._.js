module.exports=[56072,a=>{"use strict";var b=a.i(76925);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c])}];

//# sourceMappingURL=app_orders_create_layout_tsx_07168599._.js.map