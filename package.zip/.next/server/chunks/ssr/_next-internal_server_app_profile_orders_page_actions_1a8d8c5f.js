module.exports=[60887,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_profile_orders_page_actions_1a8d8c5f.js.map