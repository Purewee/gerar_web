globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f190c93b4469b1d1.js",
    "static/chunks/8404d7adcab1f184.js",
    "static/chunks/d7fed4494911480a.js",
    "static/chunks/7dab7e38d696b93b.js",
    "static/chunks/298be9aa3d95a763.js",
    "static/chunks/turbopack-a9f3091ba7d9880a.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];